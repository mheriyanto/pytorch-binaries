#pragma once

namespace torch { namespace utils {

void initializeMemoryFormats();

}} // namespace torch::utils
