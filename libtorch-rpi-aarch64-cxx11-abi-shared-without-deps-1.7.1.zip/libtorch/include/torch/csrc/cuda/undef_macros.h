#undef TH_GENERIC_FILE
#undef LIBRARY_STATE
#undef LIBRARY_STATE_NOARGS
#undef LIBRARY_STATE_TYPE
#undef LIBRARY_STATE_TYPE_NOARGS

#undef THPTensor_
#undef THPTensor_stateless_
#undef THPTensor
#undef THPTensorStr
#undef THPTensorBaseStr
#undef THPTensorClass

#undef THPTensorStatelessType
#undef THPTensorStateless
#undef THPTensorType

#undef THPStorage_
#undef THPStorageBaseStr
#undef THPStorageStr
#undef THPStorageClass
#undef THPStorageType

#undef THWStorage
#undef THWStorage_
#undef THWTensor
#undef THWTensor_

#undef THWStoragePtr
#undef THPStoragePtr
#undef THWTensorPtr
#undef THPTensorPtr


#undef THSPTensor_
#undef THSPTensor_stateless_
#undef THSPTensor
#undef THSPTensorStr
#undef THSPTensorBaseStr
#undef THSPTensorClass

#undef THSPTensorStatelessType
#undef THSPTensorStateless
#undef THSPTensorType

#undef THSPTensorPtr


#undef THHostTensor
#undef THHostTensor_
#undef THHostStorage
#undef THHostStorage_
